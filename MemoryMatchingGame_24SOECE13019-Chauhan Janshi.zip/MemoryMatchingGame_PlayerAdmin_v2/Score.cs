using System;

namespace MemoryMatchingGame
{
    public class Score
    {
        public int Id { get; set; }
        public string Player { get; set; } = string.Empty;
        public int Moves { get; set; }
        public int TimeSeconds { get; set; }
        public DateTime DateUtc { get; set; }
    }
}
