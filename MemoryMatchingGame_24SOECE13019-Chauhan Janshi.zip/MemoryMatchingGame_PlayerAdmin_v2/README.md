# Memory Matching Game (Player Admin) - WinForms (.NET 7)

This variant adds Player management so Admin can allow/disable which players can play.
- Admin > Players: insert / update / delete / enable/disable players.
- Player side: when starting a game, you must select an active player chosen by Admin.
- Database stored in memorygame.db with tables: Cards, Players, Scores.

How to run: extract ZIP, open solution in Visual Studio 2022, Build, Run (F5).
