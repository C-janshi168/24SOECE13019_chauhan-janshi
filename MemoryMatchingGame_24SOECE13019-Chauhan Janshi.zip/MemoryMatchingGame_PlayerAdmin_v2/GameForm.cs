using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    public class GameForm : Form
    {
        private TableLayoutPanel boardPanel;
        private Button btnNewGame, btnBack;
        private Label lblMoves, lblTimer, lblPlayer;
        private List<string> deckSymbols = new List<string>();
        private Button firstButton, secondButton;
        private System.Windows.Forms.Timer flipBackTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();
        private int elapsedSeconds = 0;
        private int moves = 0;
        private string currentPlayer = "";

        public GameForm()
        {
            Text = "Player - Memory Game";
            Width = 600; Height = 640;
            StartPosition = FormStartPosition.CenterParent;

            InitializeComponents();
            Load += (s, e) => BuildBoard();
        }

        private void InitializeComponents()
        {
            boardPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 4, Padding = new Padding(10) };
            btnNewGame = new Button { Text = "New Game", Dock = DockStyle.Top, Height = 30 };
            btnBack = new Button { Text = "Back", Dock = DockStyle.Top, Height = 30 };
            lblPlayer = new Label { Text = "Player: (not selected)", Dock = DockStyle.Top, Height = 24 };
            lblMoves = new Label { Text = "Moves: 0", Dock = DockStyle.Top, Height = 24 };
            lblTimer = new Label { Text = "Time: 0s", Dock = DockStyle.Top, Height = 24 };

            var topPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 140, AutoSize = false };
            topPanel.Controls.Add(btnNewGame);
            topPanel.Controls.Add(btnBack);
            topPanel.Controls.Add(lblPlayer);
            topPanel.Controls.Add(lblMoves);
            topPanel.Controls.Add(lblTimer);

            Controls.Add(boardPanel);
            Controls.Add(topPanel);

            btnNewGame.Click += (s, e) => StartNewGame();
            btnBack.Click += (s, e) => Close();

            flipBackTimer.Interval = 700;
            flipBackTimer.Tick += FlipBackTimer_Tick;

            gameTimer.Interval = 1000;
            gameTimer.Tick += (s, e) => { elapsedSeconds++; lblTimer.Text = $"Time: {elapsedSeconds}s"; };
        }

        private void BuildBoard()
        {
            boardPanel.Controls.Clear();
            boardPanel.ColumnCount = 4;
            boardPanel.RowCount = 4;
            boardPanel.ColumnStyles.Clear();
            boardPanel.RowStyles.Clear();
            for (int i = 0; i < 4; i++)
            {
                boardPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
                boardPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25f));
            }

            for (int r = 0; r < 4; r++)
                for (int c = 0; c < 4; c++)
                {
                    var b = new Button { Dock = DockStyle.Fill, Font = new Font(FontFamily.GenericSansSerif, 24f), Tag = null };
                    b.Click += Card_Click;
                    boardPanel.Controls.Add(b, c, r);
                }
        }

        private void StartNewGame()
        {
            // select player from active players
            var active = Database.GetActivePlayers();
            if (active.Count == 0)
            {
                MessageBox.Show("No active players. Ask admin to enable a player.", "No Players", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var sel = new SelectPlayerForm(active);
            if (sel.ShowDialog(this) != DialogResult.OK) return;
            currentPlayer = sel.SelectedPlayerName;
            lblPlayer.Text = $"Player: {currentPlayer}";

            elapsedSeconds = 0;
            moves = 0;
            lblMoves.Text = "Moves: 0";
            lblTimer.Text = "Time: 0s";
            firstButton = secondButton = null;

            var cards = Database.GetAllCards();
            if (cards.Count < 8)
            {
                MessageBox.Show("Admin must add at least 8 distinct symbols first.", "Not enough cards", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var rnd = new Random();
            var picked = cards.OrderBy(x => rnd.Next()).Take(8).Select(c => c.Symbol).ToList();
            deckSymbols = picked.Concat(picked).OrderBy(x => rnd.Next()).ToList();

            int i = 0;
            foreach (Control ctl in boardPanel.Controls)
            {
                if (ctl is Button b)
                {
                    b.Tag = new CardTag { Symbol = deckSymbols[i], Matched = false };
                    b.Text = "";
                    b.Enabled = true;
                    i++;
                }
            }

            gameTimer.Stop();
            gameTimer.Start();
        }

        private void Card_Click(object sender, EventArgs e)
        {
            if (flipBackTimer.Enabled) return;

            var btn = sender as Button;
            var info = btn.Tag as CardTag;
            if (info == null || info.Matched) return;

            btn.Text = info.Symbol;

            if (firstButton == null)
            {
                firstButton = btn;
                return;
            }

            if (btn == firstButton) return;

            secondButton = btn;
            moves++;
            lblMoves.Text = $"Moves: {moves}";

            var info1 = firstButton.Tag as CardTag;
            var info2 = secondButton.Tag as CardTag;
            if (info1.Symbol == info2.Symbol)
            {
                info1.Matched = true;
                info2.Matched = true;
                firstButton = secondButton = null;

                if (boardPanel.Controls.Cast<Control>().All(c => ((CardTag)c.Tag).Matched))
                {
                    gameTimer.Stop();
                    int totalTime = elapsedSeconds;
                    if (!string.IsNullOrWhiteSpace(currentPlayer))
                        Database.SaveScore(currentPlayer, moves, totalTime);
                    var msg = $"Player {currentPlayer} won! Moves: {moves}, Time: {totalTime}s";
                    MessageBox.Show(msg, "You won");
                }
                return;
            }

            flipBackTimer.Start();
        }

        private void FlipBackTimer_Tick(object sender, EventArgs e)
        {
            flipBackTimer.Stop();
            if (firstButton != null) firstButton.Text = "";
            if (secondButton != null) secondButton.Text = "";
            firstButton = secondButton = null;
        }

        private class CardTag
        {
            public string Symbol { get; set; } = "";
            public bool Matched { get; set; } = false;
        }
    }
}
