using System;
using System.Drawing;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    public class MainForm : Form
    {
        private Button btnPlayer, btnAdmin, btnScores, btnExit;
        public MainForm()
        {
            Text = "Memory Matching Game - Main";
            Width = 420;
            Height = 220;
            StartPosition = FormStartPosition.CenterScreen;

            btnPlayer = new Button { Text = "Player Side (Play)", Width = 160, Height = 40, Left = 20, Top = 20 };
            btnAdmin = new Button { Text = "Admin Side (Manage)", Width = 200, Height = 40, Left = 20, Top = 70 };
            btnScores = new Button { Text = "View Scores", Width = 160, Height = 30, Left = 20, Top = 120 };
            btnExit = new Button { Text = "Exit", Width = 80, Height = 30, Left = 240, Top = 120 };

            Controls.Add(btnPlayer);
            Controls.Add(btnAdmin);
            Controls.Add(btnScores);
            Controls.Add(btnExit);

            btnPlayer.Click += (s, e) => { var gf = new GameForm(); gf.ShowDialog(this); };
            btnAdmin.Click += (s, e) => { var af = new AdminForm(); af.ShowDialog(this); };
            btnScores.Click += (s, e) => { var sf = new ScoresForm(); sf.ShowDialog(this); };
            btnExit.Click += (s, e) => Close();
        }
    }
}
