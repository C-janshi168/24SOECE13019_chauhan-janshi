using System;
using System.Linq;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    public class AdminForm : Form
    {
        private TabControl tabs;
        private ListBox lbCards;
        private Button btnAddCard, btnEditCard, btnDeleteCard, btnRefreshCards;
        private ListBox lbPlayers;
        private Button btnAddPlayer, btnEditPlayer, btnDeletePlayer, btnToggleActive, btnRefreshPlayers;

        public AdminForm()
        {
            Text = "Admin - Manage Cards & Players";
            Width = 600; Height = 480;
            StartPosition = FormStartPosition.CenterParent;

            tabs = new TabControl { Dock = DockStyle.Fill };
            var tabCards = new TabPage("Cards");
            var tabPlayers = new TabPage("Players");

            // Cards tab
            lbCards = new ListBox { Dock = DockStyle.Top, Height = 300 };
            btnAddCard = new Button { Text = "Add", Left = 10, Width = 80 };
            btnEditCard = new Button { Text = "Edit", Left = 100, Width = 80 };
            btnDeleteCard = new Button { Text = "Delete", Left = 190, Width = 80 };
            btnRefreshCards = new Button { Text = "Refresh", Left = 280, Width = 80 };
            var pnlCards = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            pnlCards.Controls.Add(btnAddCard); pnlCards.Controls.Add(btnEditCard); pnlCards.Controls.Add(btnDeleteCard); pnlCards.Controls.Add(btnRefreshCards);
            tabCards.Controls.Add(lbCards); tabCards.Controls.Add(pnlCards);

            // Players tab
            lbPlayers = new ListBox { Dock = DockStyle.Top, Height = 300 };
            btnAddPlayer = new Button { Text = "Add", Left = 10, Width = 80 };
            btnEditPlayer = new Button { Text = "Edit", Left = 100, Width = 80 };
            btnDeletePlayer = new Button { Text = "Delete", Left = 190, Width = 80 };
            btnToggleActive = new Button { Text = "Enable/Disable", Left = 280, Width = 100 };
            btnRefreshPlayers = new Button { Text = "Refresh", Left = 390, Width = 80 };
            var pnlPlayers = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            pnlPlayers.Controls.Add(btnAddPlayer); pnlPlayers.Controls.Add(btnEditPlayer); pnlPlayers.Controls.Add(btnDeletePlayer); pnlPlayers.Controls.Add(btnToggleActive); pnlPlayers.Controls.Add(btnRefreshPlayers);
            tabPlayers.Controls.Add(lbPlayers); tabPlayers.Controls.Add(pnlPlayers);

            tabs.TabPages.Add(tabCards);
            tabs.TabPages.Add(tabPlayers);
            Controls.Add(tabs);

            Load += (s, e) => { RefreshCards(); RefreshPlayers(); };
            btnAddCard.Click += (s, e) => { AddCard(); };
            btnEditCard.Click += (s, e) => { EditCard(); };
            btnDeleteCard.Click += (s, e) => { DeleteCard(); };
            btnRefreshCards.Click += (s, e) => RefreshCards();

            btnAddPlayer.Click += (s, e) => AddPlayer();
            btnEditPlayer.Click += (s, e) => EditPlayer();
            btnDeletePlayer.Click += (s, e) => DeletePlayer();
            btnToggleActive.Click += (s, e) => TogglePlayerActive();
            btnRefreshPlayers.Click += (s, e) => RefreshPlayers();
        }

        // Cards operations
        private void RefreshCards()
        {
            lbCards.Items.Clear();
            var cards = Database.GetAllCards();
            foreach (var c in cards) lbCards.Items.Add(new ListBoxItem { Id = c.Id, Text = $"{c.Id}: {c.Symbol}" });
        }

        private void AddCard()
        {
            var sym = Prompt.ShowDialog("Enter symbol (emoji or text):", "Add Card");
            if (string.IsNullOrWhiteSpace(sym)) return;
            Database.AddCard(new Card { Symbol = sym.Trim() });
            RefreshCards();
        }

        private void EditCard()
        {
            if (lbCards.SelectedItem is ListBoxItem it)
            {
                var current = Database.GetAllCards().FirstOrDefault(x => x.Id == it.Id);
                if (current == null) return;
                var sym = Prompt.ShowDialog("Edit symbol:", "Edit Card", current.Symbol);
                if (string.IsNullOrWhiteSpace(sym)) return;
                current.Symbol = sym.Trim();
                Database.UpdateCard(current);
                RefreshCards();
            }
            else MessageBox.Show("Select a card from the list first.");
        }

        private void DeleteCard()
        {
            if (lbCards.SelectedItem is ListBoxItem it)
            {
                var ok = MessageBox.Show("Delete selected card?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (ok == DialogResult.Yes)
                {
                    Database.DeleteCard(it.Id);
                    RefreshCards();
                }
            }
            else MessageBox.Show("Select a card from the list first.");
        }

        // Players operations
        private void RefreshPlayers()
        {
            lbPlayers.Items.Clear();
            var players = Database.GetAllPlayers();
            foreach (var p in players) lbPlayers.Items.Add(new PlayerListItem { Id = p.Id, Text = $"{p.Id}: {p.Name} {(p.IsActive ? "(Active)" : "(Disabled)")}", IsActive = p.IsActive });
        }

        private void AddPlayer()
        {
            var name = Prompt.ShowDialog("Enter player name:", "Add Player");
            if (string.IsNullOrWhiteSpace(name)) return;
            Database.AddPlayer(new Player { Name = name.Trim(), IsActive = true });
            RefreshPlayers();
        }

        private void EditPlayer()
        {
            if (lbPlayers.SelectedItem is PlayerListItem it)
            {
                var current = Database.GetAllPlayers().FirstOrDefault(x => x.Id == it.Id);
                if (current == null) return;
                var name = Prompt.ShowDialog("Edit player name:", "Edit Player", current.Name);
                if (string.IsNullOrWhiteSpace(name)) return;
                current.Name = name.Trim();
                Database.UpdatePlayer(current);
                RefreshPlayers();
            }
            else MessageBox.Show("Select a player from the list first.");
        }

        private void DeletePlayer()
        {
            if (lbPlayers.SelectedItem is PlayerListItem it)
            {
                var ok = MessageBox.Show("Delete selected player?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (ok == DialogResult.Yes)
                {
                    Database.DeletePlayer(it.Id);
                    RefreshPlayers();
                }
            }
            else MessageBox.Show("Select a player from the list first.");
        }

        private void TogglePlayerActive()
        {
            if (lbPlayers.SelectedItem is PlayerListItem it)
            {
                var current = Database.GetAllPlayers().FirstOrDefault(x => x.Id == it.Id);
                if (current == null) return;
                current.IsActive = !current.IsActive;
                Database.UpdatePlayer(current);
                RefreshPlayers();
            }
            else MessageBox.Show("Select a player from the list first.");
        }

        private class ListBoxItem
        {
            public int Id { get; set; }
            public string Text { get; set; } = "";
            public override string ToString() => Text;
        }

        private class PlayerListItem : ListBoxItem
        {
            public bool IsActive { get; set; }
        }
    }
}
