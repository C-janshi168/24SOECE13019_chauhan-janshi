using System;
using System.Drawing;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    public static class Prompt
    {
        public static string? ShowDialog(string text, string caption, string defaultValue = "")
        {
            var prompt = new Form()
            {
                Width = 420,
                Height = 150,
                Text = caption,
                StartPosition = FormStartPosition.CenterParent
            };
            var lbl = new Label() { Left = 10, Top = 10, Text = text, Width = 380 };
            var txt = new TextBox() { Left = 10, Top = 35, Width = 380, Text = defaultValue };
            var ok = new Button() { Text = "OK", Left = 220, Width = 70, Top = 70, DialogResult = DialogResult.OK };
            var cancel = new Button() { Text = "Cancel", Left = 300, Width = 70, Top = 70, DialogResult = DialogResult.Cancel };
            prompt.Controls.Add(lbl); prompt.Controls.Add(txt); prompt.Controls.Add(ok); prompt.Controls.Add(cancel);
            prompt.AcceptButton = ok; prompt.CancelButton = cancel;
            return prompt.ShowDialog() == DialogResult.OK ? txt.Text : null;
        }
    }
}
