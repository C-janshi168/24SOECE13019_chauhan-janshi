using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    public class SelectPlayerForm : Form
    {
        private ComboBox cbPlayers;
        private Button btnOk, btnCancel;
        public string SelectedPlayerName { get; private set; } = "";

        public SelectPlayerForm(List<Player> players)
        {
            Text = "Select Player";
            Width = 360; Height = 140;
            StartPosition = FormStartPosition.CenterParent;

            cbPlayers = new ComboBox { Left = 10, Top = 10, Width = 320, DropDownStyle = ComboBoxStyle.DropDownList };
            foreach (var p in players) cbPlayers.Items.Add(p.Name);
            if (cbPlayers.Items.Count > 0) cbPlayers.SelectedIndex = 0;

            btnOk = new Button { Text = "OK", Left = 160, Width = 80, Top = 50, DialogResult = DialogResult.OK };
            btnCancel = new Button { Text = "Cancel", Left = 250, Width = 80, Top = 50, DialogResult = DialogResult.Cancel };

            Controls.Add(cbPlayers); Controls.Add(btnOk); Controls.Add(btnCancel);
            AcceptButton = btnOk; CancelButton = btnCancel;

            btnOk.Click += (s, e) => { if (cbPlayers.SelectedItem != null) SelectedPlayerName = cbPlayers.SelectedItem.ToString(); };
        }
    }
}
