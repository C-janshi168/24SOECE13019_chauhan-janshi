using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;

namespace MemoryMatchingGame
{
    public static class Database
    {
        private static string DbFile => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "memorygame.db");
        private static string ConnStr => $"Data Source={DbFile}";

        public static void Initialize()
        {
            var needSeed = !File.Exists(DbFile);
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Cards(
  Id INTEGER PRIMARY KEY AUTOINCREMENT,
  Symbol TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS Players(
  Id INTEGER PRIMARY KEY AUTOINCREMENT,
  Name TEXT NOT NULL,
  IsActive INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS Scores(
  Id INTEGER PRIMARY KEY AUTOINCREMENT,
  Player TEXT NOT NULL,
  Moves INTEGER NOT NULL,
  TimeSeconds INTEGER NOT NULL,
  DateUtc TEXT NOT NULL
);
";
                cmd.ExecuteNonQuery();
            }

            if (needSeed)
            {
                var defaults = new[] { "🐶","🐱","🦊","🐼","🦁","🐵","🐸","🐻" };
                foreach (var s in defaults)
                    AddCard(new Card { Symbol = s });
                // seed some players
                AddPlayer(new Player { Name = "Alice", IsActive = true });
                AddPlayer(new Player { Name = "Bob", IsActive = true });
                AddPlayer(new Player { Name = "Eve", IsActive = false });
            }
        }

        // Cards CRUD
        public static void AddCard(Card card)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Cards(Symbol) VALUES($sym);";
                cmd.Parameters.AddWithValue("$sym", card.Symbol);
                cmd.ExecuteNonQuery();
            }
        }

        public static void UpdateCard(Card card)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE Cards SET Symbol = $sym WHERE Id = $id;";
                cmd.Parameters.AddWithValue("$sym", card.Symbol);
                cmd.Parameters.AddWithValue("$id", card.Id);
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteCard(int id)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "DELETE FROM Cards WHERE Id = $id;";
                cmd.Parameters.AddWithValue("$id", id);
                cmd.ExecuteNonQuery();
            }
        }

        public static List<Card> GetAllCards()
        {
            var list = new List<Card>();
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Id, Symbol FROM Cards ORDER BY Id;";
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Card { Id = r.GetInt32(0), Symbol = r.GetString(1) });
                    }
                }
            }
            return list;
        }

        // Players CRUD
        public static void AddPlayer(Player p)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Players(Name, IsActive) VALUES($n, $a);";
                cmd.Parameters.AddWithValue("$n", p.Name);
                cmd.Parameters.AddWithValue("$a", p.IsActive ? 1 : 0);
                cmd.ExecuteNonQuery();
            }
        }

        public static void UpdatePlayer(Player p)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE Players SET Name=$n, IsActive=$a WHERE Id=$id;";
                cmd.Parameters.AddWithValue("$n", p.Name);
                cmd.Parameters.AddWithValue("$a", p.IsActive ? 1 : 0);
                cmd.Parameters.AddWithValue("$id", p.Id);
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeletePlayer(int id)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "DELETE FROM Players WHERE Id=$id;";
                cmd.Parameters.AddWithValue("$id", id);
                cmd.ExecuteNonQuery();
            }
        }

        public static List<Player> GetAllPlayers()
        {
            var list = new List<Player>();
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Id, Name, IsActive FROM Players ORDER BY Id;";
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Player { Id = r.GetInt32(0), Name = r.GetString(1), IsActive = r.GetInt32(2) == 1 });
                    }
                }
            }
            return list;
        }

        public static List<Player> GetActivePlayers()
        {
            var list = new List<Player>();
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Id, Name, IsActive FROM Players WHERE IsActive=1 ORDER BY Name;";
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Player { Id = r.GetInt32(0), Name = r.GetString(1), IsActive = r.GetInt32(2) == 1 });
                    }
                }
            }
            return list;
        }

        // Scores
        public static void SaveScore(string player, int moves, int timeSeconds)
        {
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Scores(Player, Moves, TimeSeconds, DateUtc) VALUES($p, $m, $t, $d);";
                cmd.Parameters.AddWithValue("$p", player);
                cmd.Parameters.AddWithValue("$m", moves);
                cmd.Parameters.AddWithValue("$t", timeSeconds);
                cmd.Parameters.AddWithValue("$d", DateTime.UtcNow.ToString("o"));
                cmd.ExecuteNonQuery();
            }
        }

        public static List<Score> GetTopScores(int limit = 100)
        {
            var list = new List<Score>();
            using (var conn = new SqliteConnection(ConnStr))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Id, Player, Moves, TimeSeconds, DateUtc FROM Scores ORDER BY DateUtc DESC LIMIT $lim;";
                cmd.Parameters.AddWithValue("$lim", limit);
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Score
                        {
                            Id = r.GetInt32(0),
                            Player = r.GetString(1),
                            Moves = r.GetInt32(2),
                            TimeSeconds = r.GetInt32(3),
                            DateUtc = DateTime.Parse(r.GetString(4))
                        });
                    }
                }
            }
            return list;
        }
    }
}
