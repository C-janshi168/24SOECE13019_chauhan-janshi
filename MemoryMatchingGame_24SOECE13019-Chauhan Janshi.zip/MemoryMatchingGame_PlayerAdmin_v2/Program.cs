using System;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Database.Initialize(); // ensure DB and seed (cards + players)
            Application.Run(new MainForm());
        }
    }
}
