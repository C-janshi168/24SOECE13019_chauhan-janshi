namespace MemoryMatchingGame
{
    public class Card
    {
        public int Id { get; set; }
        public string Symbol { get; set; } = string.Empty;
    }
}
