using System;
using System.Windows.Forms;

namespace MemoryMatchingGame
{
    public class ScoresForm : Form
    {
        private ListView lv;
        private Button btnClose;
        public ScoresForm()
        {
            Text = "Saved Scores";
            Width = 600; Height = 400;
            StartPosition = FormStartPosition.CenterParent;

            lv = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true };
            lv.Columns.AddRange(new[] { new ColumnHeader { Text = "Player", Width = 150 }, new ColumnHeader { Text = "Moves", Width = 80 }, new ColumnHeader { Text = "Time(s)", Width = 80 }, new ColumnHeader { Text = "Date (UTC)", Width = 240 } });
            btnClose = new Button { Text = "Close", Dock = DockStyle.Bottom, Height = 30 };
            btnClose.Click += (s, e) => Close();
            Controls.Add(lv); Controls.Add(btnClose);
            Load += (s, e) => LoadScores();
        }

        private void LoadScores()
        {
            lv.Items.Clear();
            var scores = Database.GetTopScores(200);
            foreach (var sc in scores)
            {
                var li = new ListViewItem(sc.Player);
                li.SubItems.Add(sc.Moves.ToString());
                li.SubItems.Add(sc.TimeSeconds.ToString());
                li.SubItems.Add(sc.DateUtc.ToString("o"));
                lv.Items.Add(li);
            }
        }
    }
}
